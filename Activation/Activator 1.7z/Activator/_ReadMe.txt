Instructions:
1) Mount ISO and install office
2) Make sure Office setup is closed, from Activator Folder run as ADMINISTRATOR "KMS_VL_ALL_AIO" and type 1
DONE!
 

You can always thank us here:  www.TheWindowsForum.com /  www.ThumperDC.com