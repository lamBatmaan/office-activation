  # **[Download Link](https://github.com/massgravel/Microsoft-Activation-Scripts/releases)** <br/>
   
   **Homepage:**&nbsp; https://windowsaddict.ml/ <br/>
   **Discussion:**&nbsp;&nbsp; https://discord.gg/gjJEfq7ux8<br/>

 
  **Latest Version: 1.5**<br/>
  **Release date: 11-Jan-2022**
<br/> 
<hr />

  **Microsoft Activation Scripts (MAS):**

   A collection of scripts for activating Microsoft products using HWID / KMS38 / Online KMS activation methods 
   with a focus on open-source code, less antivirus detection and user-friendliness.
 
  **Features:**
  - HWID Activation       [Downlevel & Lockbox Method]
  - KMS38 Activation      [With protection & Uninstallation option]
  - Online KMS Activation [Batch file based, no KMS related .dll .exe required]<br/>
  - $OEM$ Folder For Preactivation
  - Activation Troubleshoot
  - Insert Windows 10-11 HWID Key
  - Change Windows 10-11 Edition
  - Available in All In One & Separate Files Version
  - Fully Open Source

  <br/>

**Activations Summary:**
```
===========================================================================================
   Activation Type     Supported Product         Activation Period
===========================================================================================

   HWID             -  Windows 10-11          -  Permanent
   KMS38            -  Windows 10-11-Server   -  Until the year 2038
   Online KMS       -  Windows / Office       -  For 180 Days, renewal task needs to be 
                                                 created for lifetime auto-activation.

   * For more details, use the respective activations read me.

===========================================================================================
```
 
  # **ReadMe**

[HWID Activation](https://windowsaddict.ml/readme-hwid.html)<br/> 
[KMS38 Activation](https://windowsaddict.ml/readme-kms38.html)<br/> 
[Online KMS Activation](https://windowsaddict.ml/readme-online-kms.html)<br/> 
<br/> 
[HWID KMS38 Files Info](https://windowsaddict.ml/readme-hwid-kms38-files.html) <br/> 
[Online KMS Files Info](https://windowsaddict.ml/readme-online-kms-files.html)<br/> 
<br/> 
[Activation FAQ's](https://windowsaddict.ml/readme-activation-faq.html)<br/> 
[Extract $OEM$ Folder For Preactivation](https://windowsaddict.ml/readme-oem-folder.html)<br/> 
[Genuine Installation Media Links](https://windowsaddict.ml/readme-genuine-installation-media.html)<br/> 
[Office License Is Not Genuine Banner](https://windowsaddict.ml/office-license-is-not-genuine.html)<br/> 
[What are those big blocks of Unreadable Codes In MAS AIO Version](https://windowsaddict.ml/readme-unreadable-codes-in-mas-aio.html)<br/> 
<br/>
[Troubleshoot HWID](https://windowsaddict.ml/readme-troubleshoot-hwid.html)<br/>
[Troubleshoot KMS38](https://windowsaddict.ml/readme-troubleshoot-kms38.html)<br/>
[Troubleshoot Online KMS](https://windowsaddict.ml/readme-troubleshoot-onlinekms.html)<br/>

# [Changelog](https://windowsaddict.ml/readme-mas-changelog.html)<br/> 
# [Credits](https://windowsaddict.ml/readme-mas-credits.html)<br/> 

Made with Love ❤️
